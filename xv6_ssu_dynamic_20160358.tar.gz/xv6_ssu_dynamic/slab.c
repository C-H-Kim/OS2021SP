#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

void slabinit(){
	/* fill in the blank */
    struct slab *s;

    acquire(&stable.lock);
    int tempSize = 0x8;
    for (s = stable.slab; s < &stable.slab[NSLAB]; s++) {
        s->size = tempSize;
        s->num_pages = 1;
        s->num_free_objects = 4096 / s->size;
        s->num_used_objects = 0;
        s->num_objects_per_page = 4096 / s->size;
        s->bitmap = kalloc();
        for (int i = 0; i < 4096; i++) {
            *(s->bitmap + i) &= 0x00;
        }
        s->page[s->num_pages - 1] = kalloc();
        tempSize <<= 1;
    }
    release(&stable.lock);
}

char *kmalloc(int size){
	/* fill in the blank */
    struct slab *s;
    char *addr = 0;
    int tempSize = 0;
    int count = 0;
    int slotNum;
    int pageIdx;
    int offset;
    
    //check boundary
    if (size > 2048 || size <= 0) {
        return addr;
    }

    //find next power of 2
    if (size && !(size & (size - 1))) {
        tempSize = size;
    }
    else {
        while (size != 0) {
            size >>= 1;
            count++;
        }
        tempSize = (1 << count);
    }
    
    acquire(&stable.lock);
    //find proper slab
    for (s = stable.slab; s < &stable.slab[NSLAB]; s++) {
        if (s->size == tempSize) {
            break;
        }
    }

    //find free slab slot
    for (int i = 0; i < 4096; i++) {
        char mask = 0x1;
        for (int j = 0; j < 8; j++) {
            if(!(*(s->bitmap + i) & mask)) {
                *(s->bitmap + i) |= mask;

                //allocate one more page when free space runs out
                if (s->num_free_objects == 0) {
                    s->num_pages++;
                    s->num_free_objects = s->num_objects_per_page;
                    s->page[s->num_pages - 1] = kalloc();
                }
                
                //calculate address of slab slot
                slotNum = i * 8 + j;
                pageIdx = slotNum / s->num_objects_per_page;
                offset = slotNum % s->num_objects_per_page;

                addr = s->page[pageIdx] + offset * s->size;

                s->num_used_objects++;
                s->num_free_objects--;

                release(&stable.lock);
                return addr;
            }
            mask <<= 1;
        }
    }

    release(&stable.lock);
    return addr;
}

void kmfree(char *addr, int size){
	/* fill in the blank */
    struct slab *s;
    char *tempAddr;
    int tempSize = 0;
    int count = 0;
    int slotNum;
    int pageIdx;
    int offset;

    //find next power of 2
    if (size && !(size & (size - 1))) {
        tempSize = size;
    }
    else {
        while (size != 0) {
            size >>= 1;
            count++;
        }
        tempSize = (1 << count);
    }

    acquire(&stable.lock);
    //find proper slab
    for (s = stable.slab; s < &stable.slab[NSLAB]; s++) {
        if(s->size == tempSize) {
            break;
        }
    }

    //find match address of slab slot
    for (int i = 0; i < 4096; i++) {
        char mask = 0x1;
        for (int j = 0; j < 8; j++) {
            slotNum = i * 8 + j;
            pageIdx = slotNum / s->num_objects_per_page;
            offset = slotNum % s->num_objects_per_page;

            tempAddr = s->page[pageIdx] + offset * s->size;

            if (addr == tempAddr) {
                *(s->bitmap + i) &= ~(mask << j);

                s->num_used_objects--;
                s->num_free_objects++;

                release(&stable.lock);
                return;
            }
        }
    }

    release(&stable.lock);
    return;
}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}
